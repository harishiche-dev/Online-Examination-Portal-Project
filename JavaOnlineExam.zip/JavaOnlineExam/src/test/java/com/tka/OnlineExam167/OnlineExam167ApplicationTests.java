package com.tka.OnlineExam167;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineExam167ApplicationTests {

	@Test
	void contextLoads() {
	}

}
