package com.tka.OnlineExam167;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan("com")
@ComponentScan("com")
public class OnlineExam167Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineExam167Application.class, args);
	}

}
