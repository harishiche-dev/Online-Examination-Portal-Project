package com.tka.controller;

import java.util.HashMap;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tka.entity.Admin;
import com.tka.entity.Question;
import com.tka.entity.User;
import com.tka.service.LoginService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@RestController  
@CrossOrigin("http://localhost:4200")
public class LoginController {
	
	@Autowired
	LoginService service;
	
	static HttpSession httpSession;
	
	@Autowired
	SessionFactory factory;
	
	// {"username":"harish","password":"harish@123"}
	@PostMapping("validate")
	public Boolean validate (@RequestBody User user, HttpServletRequest request) {
		
		httpSession=request.getSession();
		
		httpSession.setAttribute("score", 0);
		httpSession.setAttribute("questionindex", 0);
		httpSession.setAttribute("username", user.getUsername());
		
		HashMap<Integer, Question> hashmap = new HashMap<>();
		httpSession.setAttribute("submitteddetails", hashmap);
		
		System.out.println(user.getUsername());
		return service.validate(user.getUsername(), user.getPassword());
	}
	
	
	// below method is to validate Admin.
	@PostMapping("validate2")
	public Boolean validate2(@RequestBody Admin userfrombrowser,HttpServletRequest request)
	{
		System.out.println("user from browser " + userfrombrowser);
	
		Session session=factory.openSession();
		
		Admin userfromdatabase=session.get(Admin.class,userfrombrowser.getUsername());
		
		System.out.println("user from database " +userfromdatabase);
					
		// this refers to that object which is used to call method
		
		if(userfromdatabase==null)
		{
			return false;
		}
		
		boolean answer=userfrombrowser.equals(userfromdatabase);
				
		System.out.println("answer from equals() of Object class is " + answer);
			
		return answer;
				
	}
}

