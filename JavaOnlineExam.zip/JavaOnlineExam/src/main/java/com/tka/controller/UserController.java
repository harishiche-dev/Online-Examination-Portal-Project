package com.tka.controller;

import java.util.Comparator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.tka.entity.User;

@RestController
@CrossOrigin("http://localhost:4200")
public class UserController 
{
		@Autowired
		SessionFactory factory;
	
		// {"username":"harish","password":"java","mobno":1234,"emailid":"harish@hvb"}
		
		@PostMapping("saveToDBUser")
		public void saveToDBUser(@RequestBody User user)
		{
			System.out.println(user);
			
			Session session=factory.openSession();
			
			Transaction tx=session.beginTransaction();
				
					session.persist(user);
			
			tx.commit();
			
		}
		
		@GetMapping("getUser/{username}")
		public User getUser(@PathVariable String username) {
			
			Session session=factory.openSession();
				
				User userfromdb=	session.get(User.class, username);
			
			return userfromdb;
			
		}
		
		@PutMapping("updateUser")
		public void updateUser(@RequestBody User user) {
			
			Session session=factory.openSession();
				
			Transaction tx= session.beginTransaction();
			
				session.merge(user);
				
			tx.commit();			
		}
		
		@DeleteMapping("deleteUser/{username}")
		public void deleteUser(@PathVariable String username) {
			
			Session session=factory.openSession();
				
			User userfromdb = session.get(User.class,username);
			
			Transaction tx= session.beginTransaction();
			
				session.remove(userfromdb);
				
			tx.commit();			
		}
		
		
}






