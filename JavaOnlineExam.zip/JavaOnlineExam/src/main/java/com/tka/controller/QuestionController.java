package com.tka.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tka.dao.QuestionDAO;
import com.tka.dto.Answer;
import com.tka.entity.Question;

import jakarta.persistence.criteria.CriteriaBuilder.In;
import jakarta.servlet.http.HttpSession;

@RestController
@CrossOrigin("http://localhost:4200")
public class QuestionController {
	
	@Autowired
	SessionFactory factory;

	@Autowired
	QuestionDAO dao;
	
	@RequestMapping("getFirstQuestion/{subject}")
	public Question getFirstQuestion (@PathVariable String subject) {
		
		List<Question> list= dao.getAllQuestions(subject);
		
		HttpSession httpSession= LoginController.httpSession;
		
		httpSession.setAttribute("allquestions", list);
		
		Question question= list.get(0);
		
		return question;
		
	}
	
	@RequestMapping("nextQuestion")
	public Question nextQuestion () {
		
		HttpSession httpSession= LoginController.httpSession;
		
		List<Question> list = (List<Question>) httpSession.getAttribute("allquestions");
		
		int questionindex = (int) httpSession.getAttribute("questionindex")+1;
		
		
		if (questionindex<list.size()) {
			
			httpSession.setAttribute("questionindex", questionindex);
			
			return list.get(questionindex);
		}
		else {
			return null;
		}		 
	}
	
	@RequestMapping("previousQuestion")
	public Question previousQuestion () {
		
		HttpSession httpSession= LoginController.httpSession;
		
		List<Question> list = (List<Question>) httpSession.getAttribute("allquestions");
		
		int questionindex = (int) httpSession.getAttribute("questionindex")+-1;
		
		
		if (questionindex>=0) {
			
			httpSession.setAttribute("questionindex", questionindex);
			
			return list.get(questionindex);
		}
		else {
			return null;
		}		 
	}
	
	//{"qno":1,"question":"what is 2+2","submittedAnswer":3,"correctAnswer":4}
	@PostMapping("saveAnswer")
	public void saveAnswer (@RequestBody Answer answer) {
		
		HttpSession httpSession= LoginController.httpSession;
		
		HashMap hashMap= (HashMap) httpSession.getAttribute("submitteddetails");
		
		hashMap.put(answer.getQno(), answer);
		
		System.out.println(hashMap);
	}
	
	@GetMapping("calculateScore")
	public int calculateScore () {
		
	HttpSession httpSession= LoginController.httpSession;
	
	HashMap hashMap= (HashMap) httpSession.getAttribute("submitteddetails");
	
	Collection<Answer> collection= hashMap.values();
	
	httpSession.setAttribute("score",0);
	
	for (Answer answer : collection) {
		if (answer.getSubmittedAnswer().equals(answer.getCorrectAnswer())) {
			httpSession.setAttribute("score", (int) httpSession.getAttribute("score")+1);
			
		}
	}
	
	return (int) httpSession.getAttribute("score");
	}
	
	@GetMapping("allAnswers")
	public Collection<Answer> allAnswers () {
		
		HttpSession httpSession= LoginController.httpSession;
		
	    HashMap hashMap =(HashMap) httpSession.getAttribute("submitteddetails");
	
	    Collection<Answer> collection= hashMap.values();
	    
	    return collection;
	}
	
	@GetMapping("getAllSubjects")
	public List<String> getAllSubjects () {
		
		Session session= factory.openSession();
		
		Query query= session.createQuery("select distinct subject from Question");
		
		List<String> list = query.list();
		
		return list;
	}
	
	@GetMapping("getAllQno/{subject}")
	public List<Integer> getAllQno (@PathVariable String subject) {
		
		Session session= factory.openSession();
		
		Query query = session.createQuery("select distinct qno from Question where subject=:subject");
		
		query.setParameter("subject", subject);
		
		List<Integer> list =  query.list();
		
		return list;
	}
	
	@GetMapping("getQuestion/{questionNumber}")
	public Question getQuestion (@PathVariable int questionNumber ) {
		
		HttpSession httpSession= LoginController.httpSession;
		
		List<Question> listofquestions = (List<Question>) httpSession.getAttribute("allquestions");
		
		Question expectedQuestion = null;
		
		for (Question question : listofquestions) {
			
			if (question.qno==questionNumber) {
				
				expectedQuestion=question;				
			}			
		}		
		return expectedQuestion;	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
