package com.tka.service;
// this service class is used for writing the business logic

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.LoginDAO;
import com.tka.entity.User;



@Service
public class LoginService {
	
	
	@Autowired
	LoginDAO dao;
	
	
	public Boolean validate(String username, String password) {
	
		String dbpassword= dao.getPasswordFromDatabase(username);
		
		if(dbpassword==null) {
			return  null;
		}
		else if(dbpassword.equals(password)) {
			return true;
		}else
			return false;
	}
	
		
}
