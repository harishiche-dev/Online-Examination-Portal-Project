import { Component, OnInit } from '@angular/core';
import { Answer, Question, QuestionService } from '../question.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-question',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './question.component.html',
  styleUrl: './question.component.css'
})
export class QuestionComponent implements OnInit{

  message:any='';
  subject:any='';
  question:Question=new Question(0,'','','','','','','');
  submittedAnswer:string='';
  answer:Answer=new Answer(0,'','','');
  maxtime:any='';
  x:any='';

  duration:any=120;
  durationMessage:string='';

  durationInterval:any='';

  selected:boolean=false;

  allAnswers:Answer[]=[];

  allQnos:number[]=[];
  

  constructor(private questionService:QuestionService,private router:Router)
  {
      this.message=sessionStorage.getItem("message");
      this.subject=sessionStorage.getItem("subject");
      questionService.getFirstQuestion(this.subject).subscribe(question=>this.question=question);

      this.durationInterval=setInterval(() =>{

        this.duration=this.duration-1;

        var minutes = Math.floor(this.duration/60);
        var seconds = this.duration%60;

        this.durationMessage=minutes + ":" + seconds ;

        if(this.duration==0)
          this.endexam();

      },1000); // after every 1 sec setInterval will execute Arroy Function
  }

  ngOnInit(): void {
    
    this.decreseTime();

    this.questionService.getAllQuestions(this.subject).subscribe(array=>this.allQnos=array);

  }

  decreseTime () {

    this.maxtime=10;

    this.x=setInterval(()=>{

      this.maxtime--;

      console.log(this.maxtime);

      if(this.maxtime==0)
        this.nextQuestion();

    },1000); // after every 1 sec setInterval will execute Arrow Function
  }

  nextQuestion()
  {
      clearInterval(this.x);

      this.decreseTime();

      this.selected=false;
      this.questionService.nextQuestion().subscribe(question=>this.question=question);
  }

  getQuestion(eventobject:any) {
    
    let questionNumber = eventobject.target.value;

    console.log("selected question number is : " + questionNumber);

    this.questionService.getQuestion(questionNumber).subscribe(question=>this.question=question);

  }

  previousQuestion()
  {
    clearInterval(this.x);

    this.decreseTime();
  
    this.selected=false;

    this.questionService.getAllAnswers().subscribe(array=>this.allAnswers=array);

    this.questionService.previousQuestion().subscribe(question=>this.question=question);
  }

  getColor(option:string) 
  {
    for (let i = 0; i < this.allAnswers.length; i++) {
      
      let answer = this.allAnswers[i];

      if (answer.qno==this.question.qno && answer.submittedAnswer==option) {
        
        return "green";
      }
      
    }
    return "red";

  }

  isChecked(option:string) 
  {
    for (let i = 0; i < this.allAnswers.length; i++) {
      
      let answer = this.allAnswers[i];

      if (answer.qno==this.question.qno && answer.submittedAnswer==option) {
        
        return true;
      }
      
    }
    return false;

  }

  saveAnswer()
  {
    this.answer.submittedAnswer=this.submittedAnswer;
    this.answer.qno=this.question.qno;
    this.answer.qtext=this.question.qtext;
    this.answer.correctAnswer=this.question.answer;

    this.questionService.saveAnswer(this.answer).subscribe();
  }

  endexam()
  {
    clearInterval(this.durationInterval);

    this.router.navigateByUrl("score");
  }
}
