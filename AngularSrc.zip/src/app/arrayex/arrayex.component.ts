import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-arrayex',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './arrayex.component.html',
  styleUrl: './arrayex.component.css'
})
export class ArrayexComponent {

  employee1:Employee = new Employee(1,'harish',100000);

  employee2:Employee = new Employee(2,'ajinkya',200000);

  employee3:Employee = new Employee(3,'vishal',400000);
  

  employees:Employee[]=[this.employee1,this.employee2,this.employee3];
}



class Employee {

  eid:number;
  name:string;
  salary:number;
  
  constructor(eid:number, name:string, salary:number) {
    this.eid=eid;
    this.name=name;
    this.salary=salary;
  }
}