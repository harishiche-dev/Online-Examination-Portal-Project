import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpclient:HttpClient) { 
    
  }

  saveResult(result:Result)
  {
    return this.httpclient.post<void>("http://localhost:8080/saveResult",result);
  }

  getRecordsCounts(subject:string)
  {
    return this.httpclient.get<number>("http://localhost:8080/getRecordsCounts/"+subject);
  }

  getResults(subject:string, pagenumber:number ) {
    
    return this.httpclient.get<Result[]>("http://localhost:8080/getResults/" + subject + "/" + pagenumber);
  }

}

  export class Result {

    username:string;
    subject:string;
    score:number;

    constructor(username:string,subject:string,score:number) {

      this.username=username;
      this.subject=subject;
      this.score=score;
    }
  }


