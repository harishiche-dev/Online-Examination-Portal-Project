import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-substraction',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './substraction.component.html',
  styleUrl: './substraction.component.css'
})
export class SubstractionComponent {

  a:number=20;
  b:number=10;

  answer:number=0;

  sub() {

    this.answer = this.a-this.b;

    console.log(this.a + " + " + this.b + " = " + this.answer);
  }
}
